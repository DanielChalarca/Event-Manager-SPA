export default function notFound() {
  return `
    <h2>Página no encontrada</h2>
    <p>La ruta ingresada no existe o no tienes permiso para verla.</p>
    <p><a href="/login" data-link>Ir a inicio de sesión</a></p>
  `;
}