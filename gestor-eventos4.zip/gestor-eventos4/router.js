import login from './views/login.js';
import register from './views/register.js';
import dashboard from './views/dashboard.js';
import createEvent from './views/createEvent.js';
import editEvent from './views/editEvent.js';
import notFound from './views/notFound.js';

import { isLoggedIn } from './auth.js';

export function router(path) {
  const app = document.getElementById('app');

  const protectedRoutes = ['/dashboard', '/dashboard/events/create', '/dashboard/events/edit'];

  if (!isLoggedIn() && protectedRoutes.some(route => path.startsWith(route))) {
    app.innerHTML = notFound();
    return;
  }

  if (isLoggedIn() && (path === '/login' || path === '/register')) {
    app.innerHTML = dashboard();
    return;
  }

  switch (path) {
    case '/':
    case '/login':
      app.innerHTML = login();
      break;
    case '/register':
      app.innerHTML = register();
      break;
    case '/dashboard':
      app.innerHTML = dashboard();
      break;
    case '/dashboard/events/create':
      app.innerHTML = createEvent();
      break;
    case '/dashboard/events/edit':
      app.innerHTML = editEvent();
      break;
    default:
      app.innerHTML = notFound();
  }
}