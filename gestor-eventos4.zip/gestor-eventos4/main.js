import { router } from './router.js';
import {
  loginUser,
  registerUser,
  authenticate,
  logoutUser
} from './auth.js';

window.addEventListener('popstate', () => {
  router(location.pathname);
});

document.addEventListener('DOMContentLoaded', () => {
  router(location.pathname);

  document.body.addEventListener('click', (e) => {
    if (e.target.matches('a[data-link]')) {
      e.preventDefault();
      const href = e.target.getAttribute('href');
      history.pushState({}, '', href);
      router(href);
    }

    if (e.target.id === 'logoutBtn') {
      logoutUser();
      router('/login');
    }
  });

  document.body.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (e.target.id === 'loginForm') {
      const email = e.target.email.value;
      const password = e.target.password.value;

      try {
        const user = await authenticate(email, password);
        loginUser(user);
        router('/dashboard');
      } catch (err) {
        alert(err.message);
      }
    }

    if (e.target.id === 'registerForm') {
      const name = e.target.name.value;
      const email = e.target.email.value;
      const password = e.target.password.value;
      const role = e.target.role.value;

      try {
        const newUser = await registerUser({ name, email, password, role });
        loginUser(newUser);
        router('/dashboard');
      } catch (err) {
        alert(err.message);
      }
    }
  });
});