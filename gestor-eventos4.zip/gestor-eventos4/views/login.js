export default function login() {
  return `
    <h2>Iniciar Sesión</h2>
    <form id="loginForm">
      <input type="email" name="email" placeholder="Correo" required />
      <input type="password" name="password" placeholder="Contraseña" required />
      <button type="submit">Entrar</button>
    </form>
    <p>¿No tienes cuenta? <a href="/register" data-link>Regístrate</a></p>
  `;
}