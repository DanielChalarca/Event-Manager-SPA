const API_URL = "http://localhost:3000/users";

export function loginUser(user) {
  localStorage.setItem("user", JSON.stringify(user));
}

export function logoutUser() {
  localStorage.removeItem("user");
}

export function getUser() {
  return JSON.parse(localStorage.getItem("user"));
}

export function isLoggedIn() {
  return !!localStorage.getItem("user");
}

export function isAdmin() {
  const user = getUser();
  return user?.role === "admin";
}

export async function registerUser(data) {
  const res = await fetch(API_URL + `?email=${data.email}`);
  const exists = await res.json();
  if (exists.length > 0) {
    throw new Error("El correo ya está registrado");
  }

  const newUser = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

  return await newUser.json();
}

export async function authenticate(email, password) {
  const res = await fetch(`${API_URL}?email=${email}&password=${password}`);
  const users = await res.json();
  if (users.length === 0) {
    throw new Error("Credenciales inválidas");
  }
  return users[0];
}