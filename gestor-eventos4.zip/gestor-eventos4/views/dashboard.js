import { getUser, isAdmin } from "../auth.js";

export default function dashboard() {
  const user = getUser();

  return `
    <h2>Bienvenido, ${user.name}</h2>
    <p>Rol: ${user.role}</p>

    <nav style="display:flex; justify-content:space-between; margin-bottom:1rem;">
      <a href="/dashboard" data-link>Inicio</a>
      ${isAdmin() ? <a href="/dashboard/events/create" data-link>Crear Evento</a> : ""}
      <button id="logoutBtn">Cerrar sesión</button>
    </nav>

    <div id="eventList">
      <h3>Eventos Disponibles</h3>
      <!-- Aquí se cargarán los eventos desde JS -->
    </div>
  `;
}

import { getUser, isAdmin } from "../auth.js";

export default function dashboard() {
  const user = getUser();

  // HTML base del dashboard
  const html = `
    <h2>Bienvenido, ${user.name}</h2>
    <p>Rol: ${user.role}</p>

    <nav style="display:flex; justify-content:space-between; margin-bottom:1rem;">
      <a href="/dashboard" data-link>Inicio</a>
      ${isAdmin() ? `<a href="/dashboard/events/create" data-link>Crear Evento</a>` : ""}
      <button id="logoutBtn">Cerrar sesión</button>
    </nav>

    <div id="eventList">
      <h3>Eventos Disponibles</h3>
      <div id="eventCards"></div>
    </div>
  `;

  // Renderizar el HTML
  setTimeout(() => {
    cargarEventos();
  }, 100);

  return html;
}

// Función que carga los eventos desde el servidor
async function cargarEventos() {
  const user = getUser();
  const container = document.getElementById("eventCards");

  try {
    const res = await fetch("http://localhost:3000/events");
    const events = await res.json();

    const registros = await fetch("http://localhost:3000/registrations");
    const allRegs = await registros.json();

    container.innerHTML = events.map(event => {
      const registrados = allRegs.filter(r => r.eventId === event.id);
      const disponible = event.capacity - registrados.length;
      const yaRegistrado = registrados.find(r => r.userId === user.id);

      return `
        <div class="event-card">
          <h4>${event.title}</h4>
          <p><strong>Fecha:</strong> ${event.date}</p>
          <p><strong>Lugar:</strong> ${event.location}</p>
          <p><strong>Capacidad:</strong> ${event.capacity}</p>
          <p><strong>Disponibles:</strong> ${disponible}</p>

          ${
            isAdmin()
              ? `
              <button onclick="editarEvento(${event.id})">Editar</button>
              <button onclick="eliminarEvento(${event.id})">Eliminar</button>
            `
              : yaRegistrado
              ? `<p>✅ Ya estás registrado</p>`
              : disponible > 0
              ? `<button onclick="registrarEvento(${event.id})">Registrarse</button>`
              : `<p>⛔ Cupo lleno</p>`
          }
        </div>
      `;
    }).join("");

  } catch (err) {
    container.innerHTML = "<p>Error al cargar eventos</p>";
  }
}

// Funciones globales para poder usarlas desde el HTML dinámico
window.eliminarEvento = async function(id) {
  if (!confirm("¿Seguro que deseas eliminar este evento?")) return;

  await fetch(`http://localhost:3000/events/${id}`, {
    method: "DELETE"
  });
  cargarEventos();
};

window.registrarEvento = async function(eventId) {
  const user = getUser();

  await fetch("http://localhost:3000/registrations", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId: user.id, eventId })
  });

  cargarEventos();
};

window.editarEvento = function(id) {
  // Guardar ID en localStorage temporalmente para usarlo en el formulario
  localStorage.setItem("editEventId", id);
  history.pushState({}, "", "/dashboard/events/edit");
  import("./editEvent.js").then(module => {
    document.getElementById("app").innerHTML = module.default();
  });
};