export default function register() {
  return `
    <h2>Registro</h2>
    <form id="registerForm">
      <input type="text" name="name" placeholder="Nombre completo" required />
      <input type="email" name="email" placeholder="Correo" required />
      <input type="password" name="password" placeholder="Contraseña" required />
      <select name="role" required>
        <option value="">Selecciona un rol</option>
        <option value="admin">Administrador</option>
        <option value="visitor">Visitante</option>
      </select>
      <button type="submit">Registrarme</button>
    </form>
    <p>¿Ya tienes cuenta? <a href="/login" data-link>Inicia sesión</a></p>
  `;
}