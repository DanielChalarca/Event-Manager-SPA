export default function editEvent() {
  return `
    <h2>Editar Evento</h2>
    <p>⚠️ Esta funcionalidad se completa desde el dashboard dinámicamente (te paso el código luego).</p>
    <p><a href="/dashboard" data-link>Volver al dashboard</a></p>
  `;
}