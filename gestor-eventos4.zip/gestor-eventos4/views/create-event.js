export default function createEvent() {
  return `
    <h2>Crear Evento</h2>
    <form id="createEventForm">
      <input type="text" name="title" placeholder="Título del evento" required />
      <input type="date" name="date" required />
      <input type="text" name="location" placeholder="Lugar" required />
      <input type="number" name="capacity" placeholder="Capacidad" required />
      <button type="submit">Crear</button>
    </form>
    <p><a href="/dashboard" data-link>Volver al dashboard</a></p>
  `;
}